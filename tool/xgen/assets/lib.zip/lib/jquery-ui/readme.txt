
Theme:Smoothness

https://github.com/jquery/jquery-ui/blob/master/ui/i18n/datepicker-zh-CN.js
