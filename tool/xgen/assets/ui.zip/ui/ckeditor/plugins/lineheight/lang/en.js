CKEDITOR.plugins.setLang('lineheight','en', {
    title: '行间距'
} );
